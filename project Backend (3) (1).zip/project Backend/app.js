const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const Product = require('./model/model.js');

const app = express();
const port = 4001;

mongoose.connect('mongodb://localhost:27017/add')
  .then(() => {
    console.log("Connection Ok");
  })
  .catch((error) => {
    console.error("Error connecting to MongoDB:", error);
  });

const methodOverride = require('method-override');
app.use(methodOverride('_method'));

app.set('view engine', 'ejs');
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));
//display all products
app.get('/products', async (req, res) => {
  try {
    const products = await Product.find({});
    res.render('display', { products });
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});

//new product 
app.get('/products/new', (req, res) => {
  res.render('index');
});
//take input of new product
app.post('/products/new', async (req, res) => {
  const { name, price, url, stock, quantity } = req.body;

  try {
    const newProduct = new Product({
      name,
      price,
      url,
      stock,
      quantity
    });

    await newProduct.save();
    res.redirect('/products');
  } catch (error) {
    console.error(error);
    res.status(500).send('Internal Server Error');
  }
});
//edit using id
app.get('/product/:id/edit',async (req,res)=>{
    const {id} = req.params;
    const product = await Product.findById(id)
    res.render('edit.ejs',{product})
})
//update product
app.put('/product/:id', async(req,res)=>{
    const {id} = req.params;
    const product = await Product.findByIdAndUpdate(id, req.body,{runValidators:true, new:true})
    res.redirect(`/product/${product._id}`);
})
//show Products
app.get('/product/:id', async(req,res)=>{
    const {id} = req.params;
    const product = await Product.findById(id)
    console.log(product)
    res.render('show' ,{product});
})
// Delete product
app.delete('/product/:id', async (req, res) => {
  try {
    let { id } = req.params;

    // Remove any non-alphanumeric characters from the end of the id
    id = id.replace(/[^a-zA-Z0-9]/g, '');

    const deletedProduct = await Product.findByIdAndDelete(id);
    
    if (!deletedProduct) {
      console.error("Product not found");
      return res.status(404).send('Product not found');
    }

    console.log(`Deleted product with id ${id}`);
    res.redirect('/products');
  } catch (error) {
    console.error("Error deleting product:", error);
    res.status(500).send('Internal Server Error');
  }
});



app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
