{
    "id": 5369122521256,
    "title": "Bauhaus Black",
    "handle": "bauhaus-century-black-watch",
    "description": "\u003cp\u003eBest known for its designs of objects based on functionalism and simplicity, the Bauhaus school of design is the inspiration behind this timepiece designed with Denis Guidone. Bauhaus Black offers a monochromatic composition showing cubes framed in a round case, with a cubed crown\u00a0to adjust\u00a0the time. This crafty watch perfectly encapsulates the Bauhaus spirit. \u003cbr\u003e\u003c\/p\u003e\n\u003cem\u003e\u003c\/em\u003e",
    "published_at": "2023-01-01T08:08:28-05:00",
    "created_at": "2020-07-02T08:31:55-04:00",
    "vendor": "Projects Watches",
    "type": "Watch",
    "tags": ["Band Color_Black", "Band Material_Leather", "Band Size_20mm", "Color_Black", "Color_Steel", "Denis Guidone", "GIFTHIM", "Height_8.85mm (0.35\")", "His", "Material_Brushed Stainless Steel", "Movement_Japanese Quartz", "NOSTALGIC", "Size_40mm (1.57\")", "Specials", "Theirs", "Water Resistant_Up to 3 ATM"],
    "price": 3450000,
    "price_min": 3450000,
    "price_max": 3450000,
    "available": true,
    "price_varies": false,
    "compare_at_price": 4900000,
    "compare_at_price_min": 4900000,
    "compare_at_price_max": 4900000,
    "compare_at_price_varies": false,
    "variants": [{
        "id": 34989170163880,
        "title": "Default Title",
        "option1": "Default Title",
        "option2": null,
        "option3": null,
        "sku": "PJT-7289B-BL",
        "requires_shipping": true,
        "taxable": true,
        "featured_image": null,
        "available": true,
        "name": "Bauhaus Black",
        "public_title": null,
        "options": ["Default Title"],
        "price": 3450000,
        "weight": 354,
        "compare_at_price": 4900000,
        "inventory_management": "shopify",
        "barcode": "095808728911",
        "quantity_rule": {
            "min": 1,
            "max": null,
            "increment": 1
        },
        "quantity_price_breaks": [],
        "requires_selling_plan": false,
        "selling_plan_allocations": []
    }],
    "images": ["\/\/cdn.shopify.com\/s\/files\/1\/0424\/8217\/2072\/files\/BAUHAUSBLACK_00941.jpg?v=1700492429", "\/\/cdn.shopify.com\/s\/files\/1\/0424\/8217\/2072\/products\/UntitledCapture0097.jpg?v=1700492429", "\/\/cdn.shopify.com\/s\/files\/1\/0424\/8217\/2072\/products\/bauhaus-black.jpg?v=1700492429", "\/\/cdn.shopify.com\/s\/files\/1\/0424\/8217\/2072\/products\/600BauhausBlack.jpg?v=1700492429", "\/\/cdn.shopify.com\/s\/files\/1\/0424\/8217\/2072\/products\/ProjectsWatchesspraycantealred.jpg?v=1700492429"],
    "featured_image": "\/\/cdn.shopify.com\/s\/files\/1\/0424\/8217\/2072\/files\/BAUHAUSBLACK_00941.jpg?v=1700492429",
    "options": [{
        "name": "Title",
        "position": 1,
        "values": ["Default Title"]
    }],
    "url": "\/products\/bauhaus-century-black-watch",
    "media": [{
        "alt": "Bauhaus Black - Projects Watches",
        "id": 33627525021910,
        "position": 1,
        "preview_image": {
            "aspect_ratio": 1.0,
            "height": 1984,
            "width": 1984,
            "src": "https:\/\/cdn.shopify.com\/s\/files\/1\/0424\/8217\/2072\/files\/BAUHAUSBLACK_00941.jpg?v=1700492429"
        },
        "aspect_ratio": 1.0,
        "height": 1984,
        "media_type": "image",
        "src": "https:\/\/cdn.shopify.com\/s\/files\/1\/0424\/8217\/2072\/files\/BAUHAUSBLACK_00941.jpg?v=1700492429",
        "width": 1984
    }, {
        "alt": "Bauhaus Black - Projects Watches",
        "id": 31993334857942,
        "position": 2,
        "preview_image": {
            "aspect_ratio": 1.0,
            "height": 1332,
            "width": 1332,
            "src": "https:\/\/cdn.shopify.com\/s\/files\/1\/0424\/8217\/2072\/products\/UntitledCapture0097.jpg?v=1700492429"
        },
        "aspect_ratio": 1.0,
        "height": 1332,
        "media_type": "image",
        "src": "https:\/\/cdn.shopify.com\/s\/files\/1\/0424\/8217\/2072\/products\/UntitledCapture0097.jpg?v=1700492429",
        "width": 1332
    }, {
        "alt": "Bauhaus Black - Projects Watches",
        "id": 21604538089640,
        "position": 3,
        "preview_image": {
            "aspect_ratio": 1.0,
            "height": 1800,
            "width": 1800,
            "src": "https:\/\/cdn.shopify.com\/s\/files\/1\/0424\/8217\/2072\/products\/bauhaus-black.jpg?v=1700492429"
        },
        "aspect_ratio": 1.0,
        "height": 1800,
        "media_type": "image",
        "src": "https:\/\/cdn.shopify.com\/s\/files\/1\/0424\/8217\/2072\/products\/bauhaus-black.jpg?v=1700492429",
        "width": 1800
    }, {
        "alt": "Bauhaus Black - Projects Watches",
        "id": 31861301870806,
        "position": 4,
        "preview_image": {
            "aspect_ratio": 1.0,
            "height": 1327,
            "width": 1327,
            "src": "https:\/\/cdn.shopify.com\/s\/files\/1\/0424\/8217\/2072\/products\/600BauhausBlack.jpg?v=1700492429"
        },
        "aspect_ratio": 1.0,
        "height": 1327,
        "media_type": "image",
        "src": "https:\/\/cdn.shopify.com\/s\/files\/1\/0424\/8217\/2072\/products\/600BauhausBlack.jpg?v=1700492429",
        "width": 1327
    }, {
        "alt": "Bauhaus Black - Projects Watches",
        "id": 21604541104296,
        "position": 5,
        "preview_image": {
            "aspect_ratio": 1.0,
            "height": 3022,
            "width": 3022,
            "src": "https:\/\/cdn.shopify.com\/s\/files\/1\/0424\/8217\/2072\/products\/ProjectsWatchesspraycantealred.jpg?v=1700492429"
        },
        "aspect_ratio": 1.0,
        "height": 3022,
        "media_type": "image",
        "src": "https:\/\/cdn.shopify.com\/s\/files\/1\/0424\/8217\/2072\/products\/ProjectsWatchesspraycantealred.jpg?v=1700492429",
        "width": 3022
    }],
    "requires_selling_plan": false,
    "selling_plan_groups": []
}