$(document).ready(function () {
    $('.img-box img').hover(function () {
      $(this).css('transform', 'scale(1.1)');
    }, function () {
      $(this).css('transform', 'scale(1)');
    });
});
// for prouct categories
$(document).ready(function(){
    $('.nav-item.dropdown').hover(function(){
      $(this).find('.dropdown-menu').first().stop(true, true).slideDown(300);
    }, function(){
      $(this).find('.dropdown-menu').first().stop(true, true).slideUp(200);
    });
  });